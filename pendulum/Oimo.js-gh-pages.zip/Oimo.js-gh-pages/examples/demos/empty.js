function demo() {


}

function update () {

    editor.tell( user.key );

}